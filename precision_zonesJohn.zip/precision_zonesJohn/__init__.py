def classFactory(iface):
    from .precision_zones import PrecisionZonesPlugin
    return PrecisionZonesPlugin(iface)

